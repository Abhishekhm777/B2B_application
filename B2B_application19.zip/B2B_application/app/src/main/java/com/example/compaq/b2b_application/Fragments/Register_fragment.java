package com.example.compaq.b2b_application.Fragments;


import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.compaq.b2b_application.AlertDialogManager;
import com.example.compaq.b2b_application.LoginActivity;
import com.example.compaq.b2b_application.MainActivity;
import com.example.compaq.b2b_application.R;
import com.example.compaq.b2b_application.Sign_up_Activity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;

/**
 * A simple {@link Fragment} subclass.
 */
public class Register_fragment extends Fragment {
public EditText first_name,last_name,email,teli_phone,password;
 public Button sign_upbutton;
    AlertDialogManager alert = new AlertDialogManager();
public String first,last,emai,telipho,pass="";
    public Register_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_register_fragment, container, false);
        sign_upbutton=(Button)view.findViewById(R.id.signup);
        first_name=(EditText)view.findViewById(R.id.first_name);
        last_name=(EditText)view.findViewById(R.id.last_name);
        email=(EditText)view.findViewById(R.id.email);
        teli_phone=(EditText)view.findViewById(R.id.telephone);
        password=(EditText)view.findViewById(R.id.password);

    sign_upbutton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            first=first_name.getText().toString();
            last=last_name.getText().toString();
            emai=email.getText().toString();
            telipho=teli_phone.getText().toString();
            pass=password.getText().toString();


                if(TextUtils.isEmpty(first.trim())) {
                    first_name.setError("First Name Is Essential");
                }
            if(TextUtils.isEmpty(last.trim())) {
                last_name.setError("Last Name Is Essential");
            }
            if(TextUtils.isEmpty(emai.trim())) {
                email.setError("Enter valid email");
            }
            if(TextUtils.isEmpty(telipho.trim())) {
                teli_phone.setError("Enter the 10digit Mobile No.");
            }if(TextUtils.isEmpty(pass.trim())) {
                password.setError("Invalid password.Password must be at least 6 characters long and contain a number");
            }
           else
            new SendPostRequest1().execute();
        }




    });
        return view;
    }

    public class SendPostRequest1 extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
        }

        protected String doInBackground(String... arg0) {

            try {

                URL url = new URL(" https://server.mrkzevar.com/uaa/api/v1/user/register/customer"); // here is your URL path

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("firstName", first);
                postDataParams.put("lastName", "last");
                postDataParams.put("email", emai);
                postDataParams.put("password", "pass");
                postDataParams.put("mobileNumber", "telipho");
                Log.e("params", postDataParams.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(5000 /* milliseconds */);
                conn.setConnectTimeout(5000 /* milliseconds */);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in = new BufferedReader(new
                            InputStreamReader(
                            conn.getInputStream()));

                    StringBuffer sb = new StringBuffer("");
                    String line = "";

                    while ((line = in.readLine()) != null) {

                        sb.append(line);
                        break;
                    }
                    in.close();

                   Log.e("Sign Up ","sb.toString()");
                    return sb.toString();

                } else {
                    alert.showAlertDialog(getContext(), "Sign-Up failed..", "Mobile No. or Email Already exist.", "fail");
                    return new String("false : " + responseCode);

                }
            } catch (Exception e) {

                return "wrong";
            }

        }

        @Override
        protected  void onPostExecute(String result) {

            if(result.equalsIgnoreCase("wrong"))
            {
                alert.showAlertDialog(getContext(), "Sign-Up failed..", "Please enter valid details", "fail");
            }
            else {

                Toast.makeText(getContext(),result,Toast.LENGTH_LONG).show();
            }
        }
    }

    public String getPostDataString(JSONObject params) throws Exception {

        StringBuilder result = new StringBuilder();
        boolean first = true;

        Iterator<String> itr = params.keys();

        while (itr.hasNext()) {

            String key = itr.next();
            Object value = params.get(key);

            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(key, "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(value.toString(), "UTF-8"));

        }
        Log.d("JSON OBJECT",result.toString());
        return result.toString();
    }

}
