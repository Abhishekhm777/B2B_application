package com.example.compaq.b2b_application;

import android.content.SharedPreferences;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.example.compaq.b2b_application.Adapters.Seller_portal_fragment1Adapter;
import com.example.compaq.b2b_application.Adapters.Sellerport_acvtivityAdaper;
import com.example.compaq.b2b_application.Adapters.Tablayout_adapter;
import com.example.compaq.b2b_application.Model.SellerPortal_model;

import java.util.ArrayList;

public class SellerPortal_Activity extends AppCompatActivity {
public Toolbar toolbar;
public RecyclerView sellser_recycler;
    public SellerPortal_model sellerPortal_model;
    public Seller_portal_fragment1Adapter seller_portal_fragment1_adapter;
    public ArrayList<SellerPortal_model> productlist;
    public SharedPreferences sharedPref;


    public TabLayout tabLayout;
    public ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_portal_);
       /* toolbar=(Toolbar)findViewById(R.id.sellerportal_toolbar);
        toolbar.setTitle("MY WHOLESALERS");
        setSupportActionBar(toolbar);*/


        tabLayout=(TabLayout)findViewById(R.id.seller_portal_tabs);

        viewPager=(ViewPager)findViewById(R.id.seller_activityadapter);

        tabLayout.addTab(tabLayout.newTab().setText("BEST SELLERS"));
        tabLayout.addTab(tabLayout.newTab().setText("MY WHOLESALERS"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final Sellerport_acvtivityAdaper adapter=new Sellerport_acvtivityAdaper(this,getSupportFragmentManager(),tabLayout.getTabCount());
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

}
