package com.example.compaq.b2b_application.Fragments;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.compaq.b2b_application.R;

import static com.example.compaq.b2b_application.SessionManagement.PREF_NAME;

/**
 * A simple {@link Fragment} subclass.
 */
public class Personal_info_fragment extends Fragment {

public EditText firstname,lastname,email,mobile;
public Button save,cancel;
    public SharedPreferences sharedPref;
public TextView edittextt,changepass;
    public Personal_info_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        sharedPref =getActivity().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_personal_info_fragment, container, false);

        firstname=view.findViewById(R.id.first_name);
        lastname=view.findViewById(R.id.last_name);
        email=view.findViewById(R.id.email);
        mobile=view.findViewById(R.id.telephone);

        save=view.findViewById(R.id.save);
        cancel=view.findViewById(R.id.cancell);

        edittextt=view.findViewById(R.id.mytextview1);
        changepass=view.findViewById(R.id.mytextview2);

        firstname.setText(sharedPref.getString("firstname", null));
        lastname.setText(sharedPref.getString("lastname", null));
        email.setText(sharedPref.getString("email", null));
        mobile.setText(sharedPref.getString("mobile", null));

        edittextt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               edittextt.setText("Edit Now");
                firstname.setFocusableInTouchMode(true);
                lastname.setFocusableInTouchMode(true);
                email.setFocusableInTouchMode(true);
                mobile.setFocusableInTouchMode(true);

            }
        });
       return  view;
    }
    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
}
