package com.example.compaq.b2b_application.Adapters;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.compaq.b2b_application.Model.Cart_recy_model;
import com.example.compaq.b2b_application.Model.Order_history_inner_model;
import com.example.compaq.b2b_application.Model.Orderhistory_model;
import com.example.compaq.b2b_application.Model.Recy_model2;
import com.example.compaq.b2b_application.R;

import java.util.ArrayList;

public class OrderHistory_adapter extends RecyclerView.Adapter<OrderHistory_adapter.ListnerViewHolder> {
    public FragmentActivity mCtx;
    private ArrayList<Orderhistory_model> productlist;
    public FragmentManager fragmentManager;
    public FragmentTransaction fragmentTransaction;
    public ImageView imageV;
    public Bundle bundle;
    private View view;
    public Context mContext;
    public SharedPreferences sharedPref;
    public   SharedPreferences.Editor myEditor;
    public OrderHistory_adapter(Context mContext, ArrayList<Orderhistory_model> productlist ) {
        this.productlist=productlist;
        this.mContext=mContext;
    }


    @NonNull
    @Override
    public OrderHistory_adapter.ListnerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        view=inflater.inflate(R.layout.orderhistory_cradlayout,parent,false);
        OrderHistory_adapter.ListnerViewHolder holder=new OrderHistory_adapter.ListnerViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull OrderHistory_adapter.ListnerViewHolder holder, int position) {
        final com.example.compaq.b2b_application.Model.Orderhistory_model listner=  productlist.get(position);

        holder.orderno.setText(listner.getOrderno());
        holder.orderdate.setText(listner.getOrderdate());

        ArrayList<Order_history_inner_model> arrayList=listner.getArrayList();

        Order_history_innerrAdapter order_history_innerrAdapter=new Order_history_innerrAdapter(mContext,arrayList);


        holder.innerRecyclerview.setLayoutManager(new LinearLayoutManager(mContext,LinearLayoutManager.VERTICAL,false));
        holder.innerRecyclerview.setHasFixedSize(true);
        holder.innerRecyclerview.setAdapter(order_history_innerrAdapter);

    }

    @Override
    public int getItemCount() {
        return productlist.size();
    }

   /* public class MyViewHolder extends RecyclerView.ViewHolder {
        RecyclerView innerRecyclerview;
        TextView orderno,orderdate;
        public Button track,cancel;
        public MyViewHolder(View itemView) {
            super(itemView);

            track=(Button)itemView.findViewById(R.id.track_button) ;
            cancel=(Button)itemView.findViewById(R.id.cancel_button);

            orderno=(TextView)itemView.findViewById(R.id.Order_set);
            orderdate=(TextView)itemView.findViewById(R.id.date_set);

            innerRecyclerview=(RecyclerView)itemView.findViewById(R.id.orderhis_inner_recycler);
        }
    }*/

    public class ListnerViewHolder extends RecyclerView.ViewHolder {
        RecyclerView innerRecyclerview;
        TextView orderno,orderdate;
        public Button track,cancel;
        public ListnerViewHolder(View view) {
            super(view);
            track=(Button)itemView.findViewById(R.id.track_button) ;
            cancel=(Button)itemView.findViewById(R.id.cancel_button);

            orderno=(TextView)itemView.findViewById(R.id.Order_set);
            orderdate=(TextView)itemView.findViewById(R.id.date_set);

            innerRecyclerview=(RecyclerView)itemView.findViewById(R.id.orderhis_inner_recycler);
        }
    }
}