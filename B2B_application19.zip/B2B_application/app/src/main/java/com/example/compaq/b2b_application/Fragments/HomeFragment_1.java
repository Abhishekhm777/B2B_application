package com.example.compaq.b2b_application.Fragments;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.compaq.b2b_application.Adapters.RecyclerAdapter1;
import com.example.compaq.b2b_application.Adapters.RecyclerItemClickListener;
import com.example.compaq.b2b_application.Adapters.ViewpageAdapter1;
import com.example.compaq.b2b_application.Model.Home_recy_model;
import com.example.compaq.b2b_application.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment_1 extends Fragment {
    private ViewPager viewPager;
    private ViewpageAdapter1 viewPageAdapter1;
    RecyclerView recyclerView;
    public  Home_recy_model home_recy_model;
    RecyclerAdapter1 adapter;
    ArrayList<Home_recy_model> productList;
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;
    private CardView cardView;
    private Context context;
    Fragment fragment_2;
    private Toolbar toolbar;

    public  HomeFragment_1() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_home_fragment_1, container, false);

        viewPager = (ViewPager) view.findViewById(R.id.viewpager);
        viewPageAdapter1 = new ViewpageAdapter1(this);

        viewPager.setAdapter(viewPageAdapter1);

        TabLayout tabLayout=(TabLayout)view.findViewById(R.id.dot_tablayout);

        tabLayout.setupWithViewPager(viewPager, true);

        productList = new ArrayList<>();
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler);

        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        recyclerView.setHasFixedSize(true);
        productList.add(new Home_recy_model(R.drawable.belt, "Belt"));

        productList.add(new Home_recy_model(R.drawable.kada, "Kada"));

        productList.add(new Home_recy_model(R.drawable.parinda, "Parinda"));

        productList.add(new Home_recy_model(R.drawable.necklace, "Necklace"));

       /* productList.add(new Home_recy_model(R.drawable.mangalsuthra, "Mangalsutra"));

        productList.add(new Home_recy_model(R.drawable.home_image6, "Necklace"));

        productList.add(new Home_recy_model(R.drawable.home_image7, "Pendants"));

        productList.add(new Home_recy_model(R.drawable.home_image8, "Phunchi"));
*/
        adapter = new RecyclerAdapter1(getActivity(), productList);
        recyclerView.setAdapter(adapter);





        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(context, new RecyclerItemClickListener.OnItemClickListener() {

                    @Override
                    public void onItemClick(View view, int position) {
                        // TODO Handle item click

                        Home_recy_model  home_recy_model =  productList.get(position);
                        String name= home_recy_model.getName();
                        Bundle bundle=new Bundle();
                        bundle.putString("Item_Clicked",name);
                        Toast.makeText(getContext(), name,Toast.LENGTH_SHORT).show();
                        toolbar = (Toolbar)getActivity().findViewById(R.id.tool_bar);

                        fragment_2=new Fragment_2();
                        fragment_2.setArguments(bundle);

                        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.mainframe,fragment_2).addToBackStack(null).commit();

                    }
                })
        );




        return  view;
    }

}
