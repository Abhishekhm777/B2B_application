package com.example.compaq.b2b_application.Adapters;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.compaq.b2b_application.AlertDialogManager;
import com.example.compaq.b2b_application.MainActivity;
import com.example.compaq.b2b_application.Model.Recy_model2;
import com.example.compaq.b2b_application.Model.SellerPortal_model;
import com.example.compaq.b2b_application.R;
import com.example.compaq.b2b_application.SellerPortal_Activity;

import java.util.ArrayList;

public class Seller_portal_fragment2Adapter extends RecyclerView.Adapter<Seller_portal_fragment2Adapter.MyViewHolder> {
    public FragmentActivity mCtx;
    private ArrayList<SellerPortal_model> productlist;
    private CardView cardView;
    private View view;
    public FragmentManager fragmentManager;
    public FragmentTransaction fragmentTransaction;
    public ImageView imageV;
    public Recy_model2 recyModel2;
    public  Recy_model2 onClickListener;
    public Bundle bundle;
    public Context mContext;
    public SharedPreferences sharedPref;
    AlertDialogManager alert = new AlertDialogManager();
    public Seller_portal_fragment2Adapter(FragmentActivity mCtx, ArrayList<SellerPortal_model> productlist ) {
        this.productlist=productlist;
        this.mCtx=mCtx;
    }
    @NonNull
    @Override
    public Seller_portal_fragment2Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(mCtx).inflate(R.layout.seller_card_layout, parent, false);
        return new Seller_portal_fragment2Adapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final SellerPortal_model sellerPortal_model=productlist.get(position);
        holder.seller_name.setText(sellerPortal_model.getName());
        Glide.with(mCtx).load(sellerPortal_model.getImageid()).into(holder.imageV);

        holder.imageV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(mCtx, MainActivity.class);
                ((SellerPortal_Activity)mCtx).finish();
                mCtx.startActivity(intent);


            }
        });
    }

    @Override
    public int getItemCount() {
        return productlist.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageV;
        TextView seller_name;
        public MyViewHolder(View itemView) {
            super(itemView);
            imageV=itemView.findViewById(R.id.sellerimage);
            seller_name=itemView.findViewById(R.id.sellername);
        }
    }
}
