package com.example.compaq.b2b_application.Model;

public class SellerPortal_model {
    private String imageid;
    private String name;

    public
    SellerPortal_model(String imageid, String name) {
        this.imageid = imageid;
        this.name = name;
    }

    public
    String getImageid() {
        return imageid;
    }

    public
    void setImageid(String imageid) {
        this.imageid = imageid;
    }

    public
    String getName() {
        return name;
    }

    public
    void setName(String name) {
        this.name = name;
    }
}
