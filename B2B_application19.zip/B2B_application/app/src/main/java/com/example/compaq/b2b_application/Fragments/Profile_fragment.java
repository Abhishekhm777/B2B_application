package com.example.compaq.b2b_application.Fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.compaq.b2b_application.R;
import com.example.compaq.b2b_application.Search_Activity;
import com.example.compaq.b2b_application.SessionManagement;

/**
 * A simple {@link Fragment} subclass.
 */
public class Profile_fragment extends Fragment {
    SessionManagement session;
    public ListView liv;
    public FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;
    public  java.util.ArrayList<String> array=new java.util.ArrayList<String>();
    android.widget.ArrayAdapter<String> adapter;
    public Profile_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        session = new SessionManagement(getContext());
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_profile_fragment, container, false);

        liv=view.findViewById(R.id.list);

        array.add("PEARSONAL INFO");
        array.add("COMPANY INFO");
        array.add("ORDER HISTORY");
        array.add("WHISHLIST");
        array.add("SELLER");
        array.add("SIGNOUT");


        adapter=new android.widget.ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,array);
        liv.setAdapter(adapter);


        liv.setClickable(true);
        liv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String items= adapter.getItem(position);
                Log.e("CLICKED",items);
                if(items.equalsIgnoreCase("SIGNOUT")){
                    session.logoutUser();
                }
                if(items.equalsIgnoreCase("ORDER HISTORY")){
                    fragmentManager = getActivity().getSupportFragmentManager();
                    fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.mainframe, new Oder_History()).commit();

                }

                if(items.equalsIgnoreCase("PEARSONAL INFO")){
                    fragmentManager = getActivity().getSupportFragmentManager();
                    fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.mainframe, new Personal_info_fragment()).commit();

                }
                if(items.equalsIgnoreCase("WHISHLIST")){
                    fragmentManager = getActivity().getSupportFragmentManager();
                    fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.mainframe, new Whish_list_fragment()).commit();

                }
            }
        });








        return  view;
    }
    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }

}
