package com.example.compaq.b2b_application.Model;

public class Order_history_inner_model {
    private String  item_name;
    private String product;
    private String sold_by;
    private String shipped_to;
    private String weight;
    private String qty;
    private String status;
    private String image_url;
    public Order_history_inner_model(String item_name, String product, String sold_by, String shipped_to, String weight,String qty,String status,String image_url) {
        this.item_name=item_name;
        this.product=product;
        this.sold_by=sold_by;
        this.shipped_to=shipped_to;
        this.weight=weight;
        this.qty=qty;
        this.status=status;
        this.image_url=image_url;

    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getSold_by() {
        return sold_by;
    }

    public void setSold_by(String sold_by) {
        this.sold_by = sold_by;
    }

    public String getShipped_to() {
        return shipped_to;
    }

    public void setShipped_to(String shipped_to) {
        this.shipped_to = shipped_to;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }
}
