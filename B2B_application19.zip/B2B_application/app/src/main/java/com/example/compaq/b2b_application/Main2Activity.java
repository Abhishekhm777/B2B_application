package com.example.compaq.b2b_application;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.compaq.b2b_application.Adapters.Inner_RecyclerAdapter4;
import com.example.compaq.b2b_application.Adapters.RecyclerAdapter3;
import com.example.compaq.b2b_application.Adapters.ViewpageAdapter2;
import com.example.compaq.b2b_application.Fragments.Check_out_fragment;
import com.example.compaq.b2b_application.Fragments.Dropdown_fragment;
import com.example.compaq.b2b_application.Fragments.HomeFragment_1;
import com.example.compaq.b2b_application.Model.Inner_Recy_model;
import com.example.compaq.b2b_application.Model.Recycler_model3;
import com.example.compaq.b2b_application.Model.Viewpager2_model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.example.compaq.b2b_application.MainActivity.ip;
import static com.example.compaq.b2b_application.SessionManagement.ACCESS_TOKEN;
import static com.example.compaq.b2b_application.SessionManagement.PREF_NAME;

public
class Main2Activity extends AppCompatActivity {
    private Toolbar toolbar2;
    private DrawerLayout drawer;
    private ViewPager viewPager;
    private ViewpageAdapter2 viewPageAdapter2;
    private Context mContext;
    ArrayList<Viewpager2_model> productlist;

    ArrayList<Recycler_model3> detProductlist;
    public RecyclerView main_recyclerView;
    public  Recycler_model3 main2_listner;
    public RecyclerAdapter3 main2_recycler_adapter;

    public RecyclerView innerRecyclerview;
    public Inner_Recy_model inner_recy_listner;
    public Inner_RecyclerAdapter4 inner_recycler_adapter;
    public   ArrayList<Inner_Recy_model> details_list;
    public    String URL_DATA="";
    public String Detail_URL_DATA="";
    public Bundle bundle;
    public TextView textView,textView2,skutext;
    public RadioGroup radioGroup ;
    private int page=0;
    private SharedPreferences sharedPref;
    public   SharedPreferences.Editor myEditor;
    public String name="";
    public String id="";
    public String item_name="";
    public String sku="";
    public String productPrice="";
    public String FinalProductPrice="";
    public static String d_url="";
    private FragmentTransaction fragmentTransaction;
    public  FragmentManager fragmentManager;
public  int json_length=0;
   /* public SharedPreferences cart_shared_preference;*/
    public static TextView textCartItemCount;

    public String cart_item_no="";
    private View actionView;



   /* public SharedPreferences.Editor cartEditor;*/

    @Override
    protected
    void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        sharedPref =getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        myEditor = sharedPref.edit();

        toolbar2=(Toolbar)findViewById(R.id.new_toolbar);

      /*  toolbar2.inflateMenu(R.menu.actionbar_icons);*/

        setSupportActionBar(toolbar2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        productlist=new ArrayList<>();
        detProductlist=new ArrayList<>();

        viewPager = (ViewPager)findViewById(R.id.viewpager2);
        TabLayout tabLayout=(TabLayout)findViewById(R.id.dot_tablayout);

        tabLayout.setupWithViewPager(viewPager, true);
        loadRecycleData();

        Button addtocart=(Button)findViewById(R.id.addtocart);

        Button buynow=(Button)findViewById(R.id.buynow);

        addtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* sharedPref=getApplicationContext().getSharedPreferences("User_information",0);*/

                String user_i =sharedPref.getString("userid","");

                userCart_details(user_i);

               /* Bundle bundle=getIntent().getExtras();
                name=bundle.getString("Item_Clicked");
                id=bundle.getString("id");

                Bundle bundle1=new Bundle();
                bundle1.putString("item_name",name);
                bundle1.putString("Item_Clicked",id);
                Dropdown_fragment dropdown_fragment =new Dropdown_fragment();
                dropdown_fragment.setArguments(bundle);
                fragmentManager = getSupportFragmentManager();
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main2, dropdown_fragment);

                fragmentTransaction.addToBackStack(null).commit();*/
            }
        });
//////////////////////////<<<<<<<<<<<<<<<<<<<<//////////////////////////////////////////

        buynow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String noOfitems=sharedPref.getString("no_of_items","");
                if (noOfitems.equalsIgnoreCase("0"))
                {
                    Toast.makeText(getApplicationContext(),"Your cart is empty!!",Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent i = new Intent(getApplicationContext(), Check_out__Activity.class);
                    startActivity(i);
                }
            }
        });
    }

    @Override
    public
    boolean onCreateOptionsMenu (Menu menu){
       /* MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.actionbar_icons, menu);
        return super.onCreateOptionsMenu(menu);*/
        getMenuInflater().inflate(R.menu.actionbar_icons, menu);

        final MenuItem menuItem = menu.findItem(R.id.cart);

       View  actionView = MenuItemCompat.getActionView(menuItem);
        textCartItemCount = (TextView) actionView.findViewById(R.id.cart_badge);
        setupBadge(getApplicationContext());
       /* cart_shared_preference = getApplicationContext().getSharedPreferences("CART_ITEMS", 0);*/
        cart_item_no=sharedPref.getString("no_of_items","");
        textCartItemCount.setText(cart_item_no);
        /* setupBadge();*/

        actionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOptionsItemSelected(menuItem);
            }
        });

        return true;
    }
    public  void setupBadge(Context context) {


        /*cart_shared_preference = context.getSharedPreferences("CART_ITEMS", 0);*/
        cart_item_no=sharedPref.getString("no_of_items","");

        textCartItemCount.setText(cart_item_no);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // click on 'up' button in the action bar, handle it here
                onBackPressed();
                return true;
            case R.id.cart:
                Intent i = new Intent(this,Cart_Activity.class);
                startActivity(i);
                return true;
            case R.id.search:
                //do sth here
                Intent ii = new Intent(this,Search_Activity.class);
                startActivity(ii);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed()
    {
        FragmentManager fm = getSupportFragmentManager();
        if (fm.getBackStackEntryCount() > 0) {
            fm.popBackStack();
        }
        else {
            super.onBackPressed();
        }
    }

    public void loadRecycleData(){
        Bundle bundle=getIntent().getExtras();
        name=bundle.getString("Item_Clicked");
       id=bundle.getString("item_name");

        String lurl=bundle.getString("lurl");

        item_name=bundle.getString("item_name");

      /*  URL_DATA="https://server.mrkzevar.com/gate/catalog/api/v1/product/all/category/"+lurl;*/

        URL_DATA=ip+"gate/b2b/catalog/api/v1/product/"+name;
        final ProgressDialog progressDialog=new ProgressDialog(Main2Activity.this);
        progressDialog.setTitle("Loading....");
        progressDialog.show();

        StringRequest stringRequest=new StringRequest(Request.Method.GET, URL_DATA, new Response.Listener<String>() {
            @Override
            public
            void onResponse(String response) {
                progressDialog.dismiss();



                try {
                    JSONObject jsonObj = new JSONObject(response);
                    JSONObject jp=jsonObj.getJSONObject("resourceSupport");

                     sku=(jp.getString("sku"));

                    JSONArray ja_data = jp.getJSONArray("links");


                    Log.d("OutPut", String.valueOf(ja_data.length()));

                    int length = ja_data.length();
                    for(int i=0; i<length; i++) {
                        JSONObject jObj = ja_data.getJSONObject(i);

                        String sname=(jObj.getString("rel"));

                        if(sname.equals("imageURl"))
                        {
                            String sliderImageUrl=jObj.getString("href");

                            Viewpager2_model item=new Viewpager2_model(sliderImageUrl);

                            productlist.add(item);











                           /* for(int j=0;j<image_arr.length();j++)
                            {
                                JSONObject img_jObj = image_arr.getJSONObject(j);
                                String relid=(img_jObj.getString("rel"));
                                if(relid.equals("imageURl")){
                                    String sliderImageUrl=img_jObj.getString("href");
                                    d_url=(jObj.getString("id"));


                                    Viewpager2_model item=new Viewpager2_model(sliderImageUrl);

                                    productlist.add(item);

                                }
                            }*/
                            detailsRecycleData();
                        }


                       /* TextView pricetextView=(TextView)findViewById(R.id.priceTextviewdetail) ;
                        pricetextView.setText("₹ "+FinalProductPrice);

                        TextView discountTextView=(TextView)findViewById(R.id.priceTextviewdetail2);
                        discountTextView.setText("₹ "+productPrice);
                        discountTextView.setPaintFlags(discountTextView.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
*/



                    }

                    viewPageAdapter2=new ViewpageAdapter2(Main2Activity.this,productlist);



                    viewPager.setAdapter(viewPageAdapter2);

                } catch (JSONException e) {
                    e.printStackTrace();
                }



            }
        }, new Response.ErrorListener() {
            @Override
            public
            void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            public Map<String, String> getHeaders() {

                sharedPref=getSharedPreferences("USER_DETAILS",0);

                String output=sharedPref.getString(ACCESS_TOKEN, null);
                Log.d("ACESSSSSS>>>>>>>>TOKEN",output);
                Map<String, String> params = new HashMap<String, String>();
                params.put("Authorization","bearer "+output);
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }
        };;;
        RequestQueue requestQueue= Volley.newRequestQueue(Main2Activity.this);
        requestQueue.add(stringRequest);
    }



    public void detailsRecycleData(){

        main_recyclerView=(RecyclerView)this.findViewById(R.id.main2recycler) ;
        main_recyclerView.setLayoutManager(new LinearLayoutManager(Main2Activity.this,LinearLayoutManager.VERTICAL,false));

        main_recyclerView.setHasFixedSize(true);


        Log.d("URL %!!!... , . ,. , . ",d_url);





       String Detail_URL_DATA=ip+"gate/b2b/catalog/api/v1/product/"+name;


        StringRequest stringRequest=new StringRequest(Request.Method.GET,  Detail_URL_DATA, new Response.Listener<String>() {
            @Override
            public
            void onResponse(String response) {



                try {
                    JSONObject   jsonObj = new JSONObject(response);
                    JSONObject jp=jsonObj.getJSONObject("resourceSupport");
                    JSONArray ja_data = jp.getJSONArray("specification");


                    Log.d("OutPut", String.valueOf(ja_data.length()));

                    int length = ja_data.length();
                    for(int i=0; i<length; i++) {
                        JSONObject jObj = ja_data.getJSONObject(i);
                        String heading=(jObj.getString("heading"));
                        main2_listner=new Recycler_model3(heading);
                        details_list=new ArrayList<>();
                        detProductlist.add(main2_listner);

                        JSONArray attribute = jObj.getJSONArray ("attributes");
                        details_list=new ArrayList<>();
                        for(int j=0;j<attribute.length();j++)
                        {
                            JSONObject attributeobjects = attribute.getJSONObject(j);

                            String key=(attributeobjects.getString("key"));
                            JSONArray attribute_values = attributeobjects.getJSONArray ("values");

                               String values=attribute_values.getString(0);
                            inner_recy_listner=new Inner_Recy_model(key,values);
                            if(heading.equalsIgnoreCase("PRODUCT DETAILS")){
                                inner_recy_listner=new Inner_Recy_model("SKU",sku);
                                details_list.add(inner_recy_listner);


                                inner_recy_listner=new Inner_Recy_model("Product Name",item_name);
                                details_list.add(inner_recy_listner);


                            }
                            inner_recy_listner=new Inner_Recy_model(key,values);
                            details_list.add(inner_recy_listner);


                        }

                        main2_listner.setArrayList(details_list);
                    }

                    main2_recycler_adapter = new RecyclerAdapter3(Main2Activity.this, detProductlist);
                    main_recyclerView.setAdapter(main2_recycler_adapter);
                    main_recyclerView.setNestedScrollingEnabled(false);
                    main2_listner.setArrayList(details_list);
                    Log.e("out", String.valueOf(details_list));



                } catch (JSONException e) {
                    e.printStackTrace();
                }



            }
        }, new Response.ErrorListener() {
            @Override
            public
            void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            public Map<String, String> getHeaders() {

                sharedPref=getSharedPreferences("USER_DETAILS",0);

                String output=sharedPref.getString(ACCESS_TOKEN, null);
                Log.d("ACESSSSSS>>>>>>>>TOKEN",output);
                Map<String, String> params = new HashMap<String, String>();
                params.put("Authorization","bearer "+output);
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }
        };;
        RequestQueue requestQueue= Volley.newRequestQueue(Main2Activity.this);
        requestQueue.add(stringRequest);
    }



    ///////////////////add to cart button pressed/////////////////////
    public void userCart_details(String us_id) {
        String url=ip+"gate/b2b/order/api/v1/cart/customer/"+us_id;
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonObjectRequest jsonObjectss = new JsonObjectRequest (Request.Method.GET,url,null,

                new Response.Listener<JSONObject>() {
                    public void onResponse(JSONObject response) {


                        try {


                            JSONArray jsonArray=response.getJSONArray("items");
                            json_length= jsonArray.length();
                            Log.e("Length....", String.valueOf(json_length));

                            /*cart_shared_preference = getApplicationContext().getSharedPreferences("CART_ITEMS", 0);
                            cartEditor= cart_shared_preference.edit();*/
                            myEditor.putString("no_of_items", String.valueOf(json_length)).apply();
                            myEditor.commit();
                           /* cart_shared_preference = getActivity().getSharedPreferences("CART_ITEMS", 0);
                            cartEditor.putString("no_of_items", String.valueOf(jsonArray.length()+1)).apply();
                            cartEditor.commit();*/
                            /*MainActivity mActivity= new MainActivity();
                            mActivity.setupBadge(getContext());
                            Main2Activity main2Activity= new Main2Activity();
                            main2Activity.setupBadge(getContext());*/


                            if (jsonArray.length() == 0 ) {
                                Bundle bundle=getIntent().getExtras();
                                name=bundle.getString("Item_Clicked");
                                id=bundle.getString("id");

                                Bundle bundle1=new Bundle();
                                bundle1.putString("item_name",name);
                                bundle1.putString("Item_Clicked",id);
                                Dropdown_fragment dropdown_fragment =new Dropdown_fragment();
                                dropdown_fragment.setArguments(bundle);
                                fragmentManager = getSupportFragmentManager();
                                fragmentTransaction = fragmentManager.beginTransaction();
                                fragmentTransaction.replace(R.id.main2, dropdown_fragment);

                                fragmentTransaction.addToBackStack(null).commit();

                            }

                            for(int i=0;i<jsonArray.length();i++) {
                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                String userCart_product_id = jsonObject1.getString("product");
                                Log.e("cart Alli irodu",userCart_product_id);

                                Log.e("Adding Alli irodu",item_name);
                                if(item_name.equalsIgnoreCase(userCart_product_id)) {
                                    Toast.makeText(getApplicationContext(), "Product is alreasy added to Cart ", Toast.LENGTH_SHORT).show();

                                    return;
                                }

                                if (i == jsonArray.length() - 1 ) {
                                    Bundle bundle=getIntent().getExtras();
                                    name=bundle.getString("Item_Clicked");
                                    id=bundle.getString("id");

                                    Bundle bundle1=new Bundle();
                                    bundle1.putString("item_name",name);
                                    bundle1.putString("Item_Clicked",id);
                                    Dropdown_fragment dropdown_fragment =new Dropdown_fragment();
                                    dropdown_fragment.setArguments(bundle);
                                    fragmentManager = getSupportFragmentManager();
                                    fragmentTransaction = fragmentManager.beginTransaction();
                                    fragmentTransaction.replace(R.id.main2, dropdown_fragment);

                                    fragmentTransaction.addToBackStack(null).commit();
                                }
                            }



                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Bundle bundle=getIntent().getExtras();
                name=bundle.getString("Item_Clicked");
                id=bundle.getString("id");

                Bundle bundle1=new Bundle();
                bundle1.putString("item_name",name);
                bundle1.putString("Item_Clicked",id);
                Dropdown_fragment dropdown_fragment =new Dropdown_fragment();
                dropdown_fragment.setArguments(bundle);
                fragmentManager = getSupportFragmentManager();
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main2, dropdown_fragment);

                fragmentTransaction.addToBackStack(null).commit();
                // ADD_CUSTOMER_CART();

            }
        }){
            @Override
            public Map<String, String> getHeaders() {
                sharedPref=getApplicationContext().getSharedPreferences("USER_DETAILS",0);

                String output=sharedPref.getString(ACCESS_TOKEN, null);

                Map<String, String> params = new HashMap<String, String>();
                params.put("Authorization","bearer "+output);
                return params;
            }

        };
        requestQueue.add(jsonObjectss);


    }

}




