package com.example.compaq.b2b_application.Fragments;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.compaq.b2b_application.Adapters.RecyclerAdapter2;
import com.example.compaq.b2b_application.Adapters.RecyclerItemClickListener;
import com.example.compaq.b2b_application.Adapters.Recycler_Adapter2;
import com.example.compaq.b2b_application.Cart_Activity;
import com.example.compaq.b2b_application.Main2Activity;
import com.example.compaq.b2b_application.MainActivity;
import com.example.compaq.b2b_application.Model.Home_recy_model;
import com.example.compaq.b2b_application.Model.Recy_model2;
import com.example.compaq.b2b_application.R;
import com.example.compaq.b2b_application.Search_Activity;
import com.example.compaq.b2b_application.SessionManagement;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.example.compaq.b2b_application.MainActivity.ip;
import static com.example.compaq.b2b_application.SessionManagement.ACCESS_TOKEN;
import static com.example.compaq.b2b_application.SessionManagement.PREF_NAME;

/**
 * A simple {@link Fragment} subclass.
 */
public
class Fragment_2 extends Fragment implements Toolbar.OnMenuItemClickListener,View.OnClickListener{
   public ArrayList<Recy_model2> productlist;
    public static   String URL_DATA="";
    private DrawerLayout drawer;
    public RecyclerView recyclerView;
    public Recy_model2 recy_model2;
    public RecyclerAdapter2 recyclerAdapter2;

    public Recycler_Adapter2 recycler_adapter2;
    public  Fragment_2 nav_fragments;
    public static String item_clicked="";
    public Bundle bundle;
    Toolbar toolbar,toolbar1,main_toolbar;
    Fragment fragment;
    private Context context;
    public String ProductPrice="";
    public  String ProductFinalPrice="";
    TextView textView;
CardView cardView;
    SharedPreferences pref;
    public View mImageBtn;

    @Override
    public
    View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_fragment_2, container, false);

        setHasOptionsMenu(true);

        toolbar=(Toolbar)view.findViewById(R.id.tool_bar);

        toolbar1=(Toolbar)view.findViewById(R.id.nav_tool);
       /* textView=(TextView)view.findViewById(R.id.toolbar_title);*/
        toolbar1.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar1.inflateMenu(R.menu.actionbar_icons);

toolbar1.setOnMenuItemClickListener(this);

        toolbar1.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public
            void onClick(View v) {
                if(getActivity().getSupportFragmentManager().getBackStackEntryCount() > 0){
                    getActivity().getSupportFragmentManager().popBackStack();
                }
                else {
                    drawer.openDrawer(GravityCompat.START);
                }
            }
        });


        recyclerView = (RecyclerView) view.findViewById(R.id.navrecycler);
        productlist=new ArrayList<>();
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        recyclerView.setHasFixedSize(true);

        loadRecycleData();


//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& Redirecting to catagory Datails after clicking&&&&&&&&&&&&&&&&&&&&&

       /* recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(context, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {
                        // TODO Handle item click
                        Recy_model2 p=  productlist.get(position);

                        String name= p.getName();
                        String id= p.getId();
                        Toast.makeText(getContext(), name,Toast.LENGTH_SHORT).show();
                        bundle=new Bundle();
                        bundle.putString("item_name",name);
                        bundle.putString("Item_Clicked",id);
                        bundle.putString("lurl",item_clicked);
                        Intent intent=new Intent(getActivity(),Main2Activity.class).putExtras(bundle);
                        startActivity(intent);
                    }

                })
        );*/

    return view;
    }
    @Override
    public void onCreateOptionsMenu(Menu menu,MenuInflater inflater) {
        inflater.inflate(R.menu.actionbar_icons, menu);
        super.onCreateOptionsMenu(menu, inflater);
        MenuItem mCartIconMenuItem = menu.findItem(R.id.cart);

        View actionView = mCartIconMenuItem.getActionView();


        actionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Cart_Activity.class);
                startActivity(intent);

            }
        });

        // mCountTv.setText(String.valueOf(mCnt1));

    }
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.navrecycler:
                break;
        }
    }
    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
    @Override
    public
    boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.search){
            Intent i = new Intent(getContext(),Search_Activity.class);
            startActivity(i);
            return true;
        }

        if (item.getItemId() == R.id.cart) {
            Intent i = new Intent(getContext(), Cart_Activity.class);
            startActivity(i);
            return true;
        }

            return super.onOptionsItemSelected(item);
    }


    public void loadRecycleData(){

       /*pref=getActivity().getSharedPreferences("USER_DETAILS",0);

        String output=pref.getString(ACCESS_TOKEN, null);
        Log.e("pref...........>>>>..","loadRecycleData................");
        Log.e("pref...........>>>>..",output);*/
        bundle=this.getArguments();
        item_clicked=bundle.getString("Item_Clicked");

       /* textView.append(item_clicked);*/
        Log.d("item rec",item_clicked);
        URL_DATA=ip+"gate/b2b/catalog/api/v1/product/all/category/"+item_clicked+"?wholesaler=37&productType=REGULAR";
        final ProgressDialog progressDialog=new ProgressDialog(getContext());
        progressDialog.setTitle("Loading....");
        progressDialog.show();

        StringRequest stringRequest=new StringRequest(Request.Method.GET, URL_DATA, new Response.Listener<String>() {
            @Override
            public
            void onResponse(String response) {
                progressDialog.dismiss();


                try {
                    JSONObject jsonObj = new JSONObject(response);
                    JSONObject jp=jsonObj.getJSONObject("products");

                   /* JSONArray jsPriceArray = jsonObj.getJSONArray("productPrice");*/

                    JSONArray ja_data = jp.getJSONArray("content");


                    int length = ja_data.length();
                    for(int i=0; i<length; i++) {
                        JSONObject jObj = ja_data.getJSONObject(i);


                            /*JSONObject priceObject = jsPriceArray.getJSONObject(i);

                            String price = String.valueOf(priceObject.getDouble("productFinalPrice"));*/
                            String sku = jObj.getString("sku");


                        String id = (jObj.getString("id"));
                        String name = (jObj.getString("name"));

                        JSONArray image_arr = jObj.getJSONArray ("links");
                        JSONObject img_jObj = image_arr.getJSONObject(1);
                        String imageurl=img_jObj.getString("href");

                        Recy_model2 item=new Recy_model2(id,imageurl,sku,name);
                        productlist.add(item);



                    }


                    recycler_adapter2 = new Recycler_Adapter2(getActivity(), productlist);



                    recyclerView.setAdapter(recycler_adapter2);



                } catch (JSONException e) {
                    e.printStackTrace();
                }



            }
        },new Response.ErrorListener() {
            @Override
            public
            void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            public Map<String, String> getHeaders() {

                pref=getActivity().getSharedPreferences("USER_DETAILS",0);

                String output=pref.getString(ACCESS_TOKEN, null);
                Map<String, String> params = new HashMap<String, String>();
                params.put("Authorization","bearer "+output);
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }


    @Override
    public
    boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.search:
                //do sth here
                Intent i = new Intent(getContext(),Search_Activity.class);
                          startActivity(i);
                return true;
        }
        switch (item.getItemId()) {
            case R.id.cart:
                //do sth here
                Intent i = new Intent(getContext(),Cart_Activity.class);
                startActivity(i);
                return true;
        }
        return false;
    }
}
