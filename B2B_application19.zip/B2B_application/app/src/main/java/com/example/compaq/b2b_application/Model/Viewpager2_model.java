package com.example.compaq.b2b_application.Model;

public
class Viewpager2_model {
    String sliderImageUrl;

    public
    Viewpager2_model(String sliderImageUrl) {
        this.sliderImageUrl=sliderImageUrl;
    }

    public String getSliderImageUrl() {
        return sliderImageUrl;
    }

    public void setSliderImageUrl(String sliderImageUrl) {
        this.sliderImageUrl = sliderImageUrl;
    }

}
