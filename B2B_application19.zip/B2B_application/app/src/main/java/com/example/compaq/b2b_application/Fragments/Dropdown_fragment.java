package com.example.compaq.b2b_application.Fragments;


import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.compaq.b2b_application.Main2Activity;
import com.example.compaq.b2b_application.MainActivity;
import com.example.compaq.b2b_application.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.example.compaq.b2b_application.MainActivity.ip;
import static com.example.compaq.b2b_application.SessionManagement.ACCESS_TOKEN;
import static com.example.compaq.b2b_application.SessionManagement.PREF_NAME;

/**
 * A simple {@link Fragment} subclass.
 */
public class Dropdown_fragment extends Fragment {

    public static FragmentManager fragmentManager;
    public static TextView displayInteger;
    public static int minteger = 1;
    public Spinner spinner;
    private FragmentTransaction fragmentTransaction;
    public List<String> list;
   /* SharedPreferences pref;*/
    public Bundle bundle;
    public String item_clicked = "";
    public String item_id = "";
    public double item_wieght;
    public TextView weight_edittext, quantity_edittext, weight_edit;
    public Button cancelbtn, submitbtn;
    public SharedPreferences sharedPref;
    public SharedPreferences.Editor myEditor;
    public String cartid, userid, seal, qty, weig = "";
    public String user_cartid_de="";
  /* public SharedPreferences.Editor myEditor1;*/
public int json_length=0;
    private static final String cartitems = "CART_ITEMS";
   /* SharedPreferences cart_shared_preference;
    SharedPreferences.Editor cartEditor;
*/
    String url="";
    public Dropdown_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_dropdown_fragment, container, false);

        sharedPref =getActivity().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        myEditor = sharedPref.edit();


       /* cart_shared_preference = getActivity().getSharedPreferences(cartitems, Context.MODE_PRIVATE);
        cartEditor = cart_shared_preference.edit();
*/






        cancelbtn = (Button) view.findViewById(R.id.cancel);
        submitbtn = (Button) view.findViewById(R.id.submit);
        quantity_edittext = (TextView) view.findViewById(R.id.result);
        weight_edittext = (TextView) view.findViewById(R.id.weight);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               minteger=1;
                getActivity().onBackPressed();
            }
        });
        displayInteger = (TextView) view.findViewById(R.id.result);
        Button button = (Button) view.findViewById(R.id.increas);
        Button button2 = (Button) view.findViewById(R.id.decrease);

        button.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                minteger = minteger + 1;
                display(minteger);

                String d = weight_edittext.getText().toString();
                Double va = Double.parseDouble(d);
                weight_edittext.setText(String.valueOf(Math.abs(item_wieght + va)));

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (minteger > 1) {
                    minteger = minteger - 1;
                    display(minteger);

                    String d = weight_edittext.getText().toString();
                    Double va = Double.parseDouble(d);
                    weight_edittext.setText(String.valueOf(Math.abs(va - item_wieght)));

                }
            }
        });

        itemDetails();
        list = new ArrayList<>();
        list.add("Select SEAL");
        sealList();


        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), R.layout.support_simple_spinner_dropdown_item, list) {
            @Override
            public boolean isEnabled(int position) {
                if (position == 0) {
                    // Disable the first item from Spinner
                    // First item will be use for hint
                    return false;
                } else {
                    return true;
                }
            }


        };

        spinner = (Spinner) view.findViewById(R.id.spinner);
        spinner.setPrompt("SEAL");
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    // Disable the first item from Spinner
                    // First item will be use for hin
                } else {

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        ////////////////////////submit button//////////////
        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seal = spinner.getSelectedItem().toString();
                weig = weight_edittext.getText().toString();
                qty = quantity_edittext.getText().toString();
              /*  sharedPref = getActivity().getSharedPreferences("User_information", 0);*/
                cartid = sharedPref.getString("cartid", "");
                userid = sharedPref.getString("userid", "");

                Log.e("user id", userid);
                Log.e("cart id", cartid);
                Log.e("qty", qty);
                Log.e("Wiegt", weig);
                Log.e("SEAL", seal);
                Log.e("product", item_clicked);
                Log.e("product_id", item_id);


                updateCart();
            }
        });


        return view;
    }

    private void display(int number) {
        displayInteger.setText("" + number);
    }


    ///////////adding Seal list to drop down////////////////////////////////////////////////////
    public void sealList() {

        String url = ip+"gate/b2b/order/api/v1/order/seal";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jsonArray = new JSONArray(response);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        list.add(jsonArray.getString(i));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {

                sharedPref = getActivity().getSharedPreferences("USER_DETAILS", 0);

                String output = sharedPref.getString(ACCESS_TOKEN, null);
                Map<String, String> params = new HashMap<String, String>();
                params.put("Authorization", "bearer " + output);
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }

    /////////////////////////////////////////----item specification//////////////////////////
    public void itemDetails() {
        bundle = this.getArguments();
        item_clicked = bundle.getString("item_name");
        item_id = bundle.getString("Item_Clicked");
        String url = ip+"gate/b2b/catalog/api/v1/product/" + item_clicked;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject jp = jsonObject.getJSONObject("resourceSupport");

                    JSONArray jsonArray = jp.getJSONArray("weights");
                    item_wieght = Double.parseDouble(((jsonArray.getString(0))));
                    weight_edittext.setText(String.valueOf(item_wieght));
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {

                sharedPref = getActivity().getSharedPreferences("USER_DETAILS", 0);

                String output = sharedPref.getString(ACCESS_TOKEN, null);
                Map<String, String> params = new HashMap<String, String>();
                params.put("Authorization", "bearer " + output);
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }
        };


        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }
    ////////////////////////updating cart///////////////////////////////////////
   /* public void updateCart ( ){

        JSONObject json1= new JSONObject();
        final JSONArray items_jsonArray=new JSONArray();
        try {
            json1.put("product","GEK015");
            json1.put("productID","5c403bdfeb3c814f80b76fa2");
            json1.put("quantity",1);
            json1.put("advance","");
            json1.put("description","");
            json1.put("seal","MRK");
            json1.put("melting","");
            json1.put("rate","");
            json1.put("netWeight","44.820");

            items_jsonArray.put(json1);


        } catch (JSONException e) {
            e.printStackTrace();
        }



        String url="https://server.mrkzevar.com/gate/b2b/order/api/v1/cart/update";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

Log.e("UPDATE CATR,,,,,,,", String.valueOf(jsonObject));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            public Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("customer", String.valueOf(253));
                params.put("items", String.valueOf(items_jsonArray));
                params.put("id", String.valueOf(51));
                return params;
            }
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError{

                pref=getActivity().getSharedPreferences("USER_DETAILS",0);

                String output=pref.getString(ACCESS_TOKEN, null);
                Map<String, String> headr = new HashMap<String, String>();
                headr.put("Authorization","bearer "+output);
                headr.put("Content-Type", "application/x-www-form-urlencoded");
                return headr;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }*/

    public void updateCart() {

        JSONObject mainJasan= new JSONObject();
        if(cartid.equalsIgnoreCase("0")){
            url=ip+"gate/b2b/order/api/v1/cart/add";


            JSONObject json1= new JSONObject();
            final JSONArray items_jsonArray=new JSONArray();
            try {
                json1.put("product",item_clicked);
                json1.put("productID",item_id);
                json1.put("quantity",qty);
                json1.put("advance","");
                json1.put("description","");
                json1.put("seal",seal);
                json1.put("melting","");
                json1.put("rate","");
                json1.put("netWeight",weig);

                items_jsonArray.put(json1);
                mainJasan.put("customer",userid);
                mainJasan.put("items",items_jsonArray);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Map<String, String> params = new HashMap<>();
            params.put("customer", userid);
            params.put("items", String.valueOf(items_jsonArray));

        }
        else {
            url = ip+"gate/b2b/order/api/v1/cart/update";


            JSONObject json1= new JSONObject();
            final JSONArray items_jsonArray=new JSONArray();
            try {
                json1.put("product",item_clicked);
                json1.put("productID",item_id);
                json1.put("quantity",qty);
                json1.put("advance","");
                json1.put("description","");
                json1.put("seal",seal);
                json1.put("melting","");
                json1.put("rate","");
                json1.put("netWeight",weig);

                items_jsonArray.put(json1);
                mainJasan.put("customer",userid);
                mainJasan.put("items",items_jsonArray);
                mainJasan.put("id",cartid);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Map<String, String> params = new HashMap<>();
            params.put("customer", userid);
            params.put("items", String.valueOf(items_jsonArray));
            params.put("id", cartid);
        }




        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, mainJasan, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {

                try {

                    String cartid=response.getString("id");

                    sharedPref =getActivity().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
                    myEditor = sharedPref.edit();

                    myEditor.putString("cartid",cartid);
                    myEditor.apply();
                    myEditor.commit();
                    JSONArray jsonArray=response.getJSONArray("items");
/*
                    Log.e("No of items in cart", String.valueOf(jsonArray.length()));
                    cart_shared_preference = getActivity().getSharedPreferences("CART_ITEMS", 0);
                   cartEditor.putString("no_of_items", String.valueOf(jsonArray.length())).apply();
                   cartEditor.commit();*/

                   /* cart_shared_preference = getActivity().getSharedPreferences("CART_ITEMS", 0);*/
                   json_length= Integer.parseInt(sharedPref.getString("no_of_items",""));
                    myEditor.putString("no_of_items", String.valueOf(json_length+1)).apply();
                    myEditor.commit();
                    MainActivity mActivity= new MainActivity();
                    mActivity.setupBadge(getContext());
                   /* Main2Activity main2Activity= new Main2Activity();
                    main2Activity.setupBadge(getContext());*/
                    Toast.makeText(getContext(), "Added to cart", Toast.LENGTH_SHORT).show();
                    getActivity().onBackPressed();
                }

                // Go to next activity

                 catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                  Log.d("Error", String.valueOf(error));
                Toast.makeText(getContext(), "Please select SEAL", Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                HashMap<String, String> headr = new HashMap<>();
                sharedPref=getActivity().getSharedPreferences("USER_DETAILS",0);

                String output=sharedPref.getString(ACCESS_TOKEN, null);
                headr.put("Authorization","bearer "+output);
                headr.put("Content-Type", "application/json");
                return headr;
            }
        };
        RequestQueue queue = Volley.newRequestQueue(getContext());
        queue.add(request);
    }
/////////////////////////check the user cart details for item exist/////////////////////////

   /* public void userCart_details() {
        String url="https://server.mrkzevar.com/gate/b2b/order/api/v1/cart/customer/"+userid;
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        JsonObjectRequest jsonObjectss = new JsonObjectRequest (Request.Method.GET,url,null,

                new Response.Listener<JSONObject>() {
                    public void onResponse(JSONObject response) {


                        try {

                            user_cartid_de=response.getString("id");
                            JSONArray jsonArray=response.getJSONArray("items");
                            json_length= jsonArray.length();

                           *//* cart_shared_preference = getActivity().getSharedPreferences("CART_ITEMS", 0);
                            cartEditor.putString("no_of_items", String.valueOf(jsonArray.length()+1)).apply();
                            cartEditor.commit();*//*
                            *//*MainActivity mActivity= new MainActivity();
                            mActivity.setupBadge(getContext());
                            Main2Activity main2Activity= new Main2Activity();
                            main2Activity.setupBadge(getContext());*//*


                            if (jsonArray.length() == 0 ) {
                                updateCart();
                            }

                            for(int i=0;i<jsonArray.length();i++) {
                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                String userCart_product_id = jsonObject1.getString("productID");

                                if(item_id.equalsIgnoreCase(userCart_product_id)) {
                                    Toast.makeText(getContext(), "Product is alreasy added to Cart ", Toast.LENGTH_SHORT).show();
                                    getActivity().onBackPressed();
                                   return;
                                }

                                if (i == jsonArray.length() - 1 ) {
                                    updateCart();
                                }
                            }



                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

                // ADD_CUSTOMER_CART();

            }
        }){
            @Override
            public Map<String, String> getHeaders() {
                pref=getActivity().getSharedPreferences("USER_DETAILS",0);

                String output=pref.getString(ACCESS_TOKEN, null);

                Map<String, String> params = new HashMap<String, String>();
                params.put("Authorization","bearer "+output);
                return params;
            }

        };
        requestQueue.add(jsonObjectss);


    }*/

}


