package com.example.compaq.b2b_application.Fragments;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.compaq.b2b_application.Adapters.Cart_recycler_Adapter;
import com.example.compaq.b2b_application.Adapters.Seller_portal_fragment1Adapter;
import com.example.compaq.b2b_application.Model.Cart_recy_model;
import com.example.compaq.b2b_application.Model.SellerPortal_model;
import com.example.compaq.b2b_application.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.example.compaq.b2b_application.MainActivity.ip;
import static com.example.compaq.b2b_application.SessionManagement.ACCESS_TOKEN;
import static com.example.compaq.b2b_application.SessionManagement.PREF_NAME;

/**
 * A simple {@link Fragment} subclass.
 */
public class SellerPortal_fragment1 extends Fragment {

    public RecyclerView sellser_recycler;
    public SellerPortal_model sellerPortal_model;
    public Seller_portal_fragment1Adapter seller_portal_fragment1_adapter;
    public ArrayList<SellerPortal_model> productlist;
    public SharedPreferences sharedPref;
    public String output;
    SharedPreferences.Editor myEditior;


    public SellerPortal_fragment1() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_seller_portal_fragment1, container, false);
        productlist=new ArrayList<>();
        sellser_recycler = (RecyclerView)view.findViewById(R.id.seller_recycler1);
        sellser_recycler.setLayoutManager(new GridLayoutManager(getContext(), 1));
        sellerLogo();
   return  view;
    }

    public void sellerLogo ( ){

        String url="http://192.168.100.11:8769/uaa/b2b/api/v1/user/wholesalers?product=jewellery";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jObj = new JSONObject(response);

                   JSONObject embedeobject=jObj.getJSONObject("_embedded");
                   JSONArray user_array=embedeobject.getJSONArray("userList");

                   for(int i=0;i<user_array.length();i++){
                       JSONObject object=user_array.getJSONObject(i);
                       String seller_id=new String();
                       object.getString("id");
                       String seller_name=object.getString("firstName");

                       sharedPref =getActivity().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
                       myEditior = sharedPref.edit();

                       myEditior.putString("Seller_id",seller_id);
                       myEditior.putString("Seller_name",seller_name).apply();
                       myEditior.commit();


                       JSONObject comanyarray=object.getJSONObject("_links");

                       JSONObject urlobject=comanyarray.getJSONObject("company");

                       String sellerurl=urlobject.getString("href");

                       getLogo(sellerurl);
                   }



                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            public Map<String, String> getHeaders() {

                sharedPref=getActivity().getApplicationContext().getSharedPreferences("USER_DETAILS",0);

                 output=sharedPref.getString(ACCESS_TOKEN, null);

                Map<String, String> params = new HashMap<String, String>();
                params.put("Authorization","bearer "+output);
                return params;
            }
        };




        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }



    public void getLogo (String url ){


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jObj = new JSONObject(response);

                        String companyname=jObj.getString("name");
                        JSONObject comanyarray=jObj.getJSONObject("_links");

                        JSONObject urlobject=comanyarray.getJSONObject("logo");

                        String imageurl=urlobject.getString("href");





                     productlist.add(new SellerPortal_model(imageurl,companyname));


                    seller_portal_fragment1_adapter = new Seller_portal_fragment1Adapter(getActivity(), productlist);
                    /*recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));*/
                    sellser_recycler.setAdapter(seller_portal_fragment1_adapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            public Map<String, String> getHeaders() {


                Map<String, String> params = new HashMap<String, String>();
                params.put("Authorization","bearer "+output);
                return params;
            }
        };




        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }

}
