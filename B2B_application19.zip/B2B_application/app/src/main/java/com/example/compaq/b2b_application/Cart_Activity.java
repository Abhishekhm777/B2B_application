package com.example.compaq.b2b_application;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.compaq.b2b_application.Adapters.Cart_recycler_Adapter;
import com.example.compaq.b2b_application.Adapters.RecyclerAdapter2;
import com.example.compaq.b2b_application.Adapters.Recycler_Adapter2;
import com.example.compaq.b2b_application.Fragments.Check_out_fragment;
import com.example.compaq.b2b_application.Fragments.HomeFragment_1;
import com.example.compaq.b2b_application.Model.Cart_recy_model;
import com.example.compaq.b2b_application.Model.Recy_model2;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static android.widget.Toast.LENGTH_SHORT;
import static android.widget.Toast.makeText;
import static com.example.compaq.b2b_application.MainActivity.ip;
import static com.example.compaq.b2b_application.SessionManagement.ACCESS_TOKEN;
import static com.example.compaq.b2b_application.SessionManagement.PREF_NAME;

public class Cart_Activity extends AppCompatActivity {
    public Toolbar toolbar;
    public static TextView pricetext_view;
    public RecyclerView recyclerView;
    public Cart_recy_model cart_recy_model;
    public Cart_recycler_Adapter cart_recycler_adapter;
    public ArrayList<Cart_recy_model> productlist;
   /* SharedPreferences pref;*/
    public Bundle bundle;
    public String userid="";
    public SharedPreferences sharedPref;
    public   SharedPreferences.Editor myEditor;
    public    ArrayList<String>product_id;
    public    ArrayList<String>seal_list;
    public    ArrayList<String>weigh_list;
    public    ArrayList<String>qty_list;
    public String prod_id="";
    public String href="";
    public String seal="";
    public String wieght="";
    public String qty="";
    public JSONArray ja_data;
    public double total_price=0;
    AlertDialogManager alert = new AlertDialogManager();
    public Button check_out;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_);
        toolbar=(Toolbar)findViewById(R.id.cart_toolbar);
        toolbar.setTitle("My Cart");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

       /* pricetext_view=(TextView)findViewById(R.id.total_price);*/


        sharedPref =getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        myEditor = sharedPref.edit();



        check_out=(Button)findViewById(R.id.check_out_btn);
        check_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Fragment checkfragment=new Check_out_fragment();
                FragmentManager fragmentManager=getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.contaner, checkfragment).addToBackStack(null);;
                fragmentTransaction.commit();*/
                String noOfitems=sharedPref.getString("no_of_items","");

                if (noOfitems.equalsIgnoreCase("0"))
                {
                    Toast.makeText(getApplicationContext(),"Your cart is empty!!",Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent i = new Intent(getApplicationContext(), Check_out__Activity.class);
                    startActivity(i);
                }
            }
        });

        recyclerView = (RecyclerView)findViewById(R.id.cart_recycler);
        productlist=new ArrayList<>();
        seal_list=new ArrayList<>();
        weigh_list=new ArrayList<>();
        qty_list=new ArrayList<>();
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 1));
        recyclerView.setHasFixedSize(true);

        getItem_ids();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // click on 'up' button in the action bar, handle it here
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed()
    {
        FragmentManager fm = getSupportFragmentManager();
        if (fm.getBackStackEntryCount() > 0) {
            fm.popBackStack();
        }
        else {

            super.onBackPressed();
        }
    }

    public  void getItem_ids() {

       /* sharedPref = getSharedPreferences("User_information", 0);*/
        userid = sharedPref.getString("userid", "");
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest jsonArrayRequest = new StringRequest(
                ip+"gate/b2b/order/api/v1/cart/customer/"+userid+"",
                new Response.Listener<String>() {
                    public void onResponse(String response) {
                        product_id=new ArrayList<>();


                        try {
                            JSONObject jsonObject = new JSONObject(response);

                             ja_data = jsonObject.getJSONArray("items");
                             Log.e("length...", String.valueOf(ja_data.length()));

                            if (ja_data.length()==0)
                            {
                                ImageView imageView=findViewById(R.id.cart_emppty);
                                imageView.setImageResource(R.drawable.emptycart);
                            }
                            for (int i = 0; i < ja_data.length(); i++) {
                                JSONObject jsonObject1 = ja_data.getJSONObject(i);

                                String se=jsonObject1.getString("seal");
                                String we=jsonObject1.getString("netWeight");
                                String pid=jsonObject1.getString("productID");
                                Log.e("cartrtrttrtrt",se+we+   pid);
                               int delete_ids= Integer.parseInt(jsonObject1.getString("id"));

                                    display_cart_details(pid,we,se,delete_ids);

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            ImageView imageView=findViewById(R.id.cart_emppty);
                            imageView.setImageResource(R.drawable.emptycart);

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                ImageView imageView=findViewById(R.id.cart_emppty);
                imageView.setImageResource(R.drawable.emptycart);
            }
        }){
            @Override
            public Map<String, String> getHeaders() {
                sharedPref=getSharedPreferences("USER_DETAILS",0);

                String output=sharedPref.getString(ACCESS_TOKEN, null);
                Map<String, String> params = new HashMap<String, String>();
                params.put("Authorization","bearer "+output);
                return params;
            }

        };
        requestQueue.add(jsonArrayRequest);


    }
    //////////////// fetching cart details//////////////////////////

    public void display_cart_details(final String id,final String weght,final String sealw,final int del_id) {

        String url=ip+"gate/b2b/catalog/api/v1/product"+id;
        final ProgressDialog progressDialog=new ProgressDialog(Cart_Activity.this);
        progressDialog.setTitle("Loading....");
        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                    ip+"gate/b2b/catalog/api/v1/product/"+id+"",
                    new Response.Listener<String>() {

                        @Override
                        public void onResponse(String response) {

                            progressDialog.dismiss();
                            try {
                                int k = 0;
                                JSONObject obj = new JSONObject(response);
                                JSONObject obj1 = obj.getJSONObject("resourceSupport");
                                String name = obj1.getString("name");
                                String product_id = obj1.getString("id");



                                JSONArray ja_data = obj1.getJSONArray("links");
                                for (int i = 0; i < ja_data.length(); i++) {
                                    JSONObject jObj = ja_data.getJSONObject(i);
                                    for (Iterator<String> iterator = jObj.keys(); iterator.hasNext(); ) {
                                        String key = (String) iterator.next();

                                        if (jObj.get(key).equals("imageURl") && k < 1) {
                                            href = jObj.getString("href");
                                            k++;
                                        }
                                    }
                                }
                              /*  JSONObject obj2 = obj.getJSONObject("priceandseller");
                                JSONObject jsonObject1 = obj2.getJSONObject("price");
                                String new_price = jsonObject1.getString("productFinalPrice");
                                String old_price = jsonObject1.getString("productPrice");*/


                              /*  total_price = (Math.round((total_price + (Double.parseDouble(new_price))) * 100D) / 100D);

                                Log.d("price", total_price + "");*/



                                productlist.add(new Cart_recy_model(name, href, weght, product_id, sealw,del_id));


                                    cart_recycler_adapter = new Cart_recycler_Adapter(getApplicationContext(), productlist);
                                    /*recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));*/
                                    recyclerView.setAdapter(cart_recycler_adapter);



                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }


                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    //displaying the error in toast if occurrs
                    makeText(getApplicationContext(), error.getMessage(), LENGTH_SHORT).show();
                }
            }){
                @Override
                public Map<String, String> getHeaders() {

                    sharedPref=getSharedPreferences("USER_DETAILS",0);

                    String output=sharedPref.getString(ACCESS_TOKEN, null);
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Authorization","bearer "+output);
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);

            requestQueue.add(stringRequest);
        }
    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(!ConnectivityStatus .isConnected(getApplicationContext())){
                alert.showAlertDialog(Cart_Activity.this, "No Internet!", "Please Check your internet Connection", "internet");
            }else {
                // connected

            }
        }
    };
    @Override
    protected void onResume() {
        super.onResume();
        getApplicationContext().registerReceiver(receiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));

    }

    @Override
    protected void onPause() {
        super.onPause();
        getApplicationContext().registerReceiver(receiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));


    }


    }


