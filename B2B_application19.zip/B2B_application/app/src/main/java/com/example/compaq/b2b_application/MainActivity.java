package com.example.compaq.b2b_application;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.compaq.b2b_application.Fragments.Dropdown_fragment;
import com.example.compaq.b2b_application.Fragments.Fragment_2;
import com.example.compaq.b2b_application.Fragments.HomeFragment_1;
import com.example.compaq.b2b_application.Fragments.Profile_fragment;
import com.example.compaq.b2b_application.Fragments.Seller_fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.example.compaq.b2b_application.Fragments.Fragment_2.URL_DATA;
import static com.example.compaq.b2b_application.Fragments.Fragment_2.item_clicked;
import static com.example.compaq.b2b_application.SessionManagement.ACCESS_TOKEN;
import static com.example.compaq.b2b_application.SessionManagement.KEY_NAME;
import static com.example.compaq.b2b_application.SessionManagement.PREF_NAME;
import static com.example.compaq.b2b_application.SessionManagement.USERNAME_FIRSTNAME;

public
class MainActivity extends AppCompatActivity {
    public static String ip="http://192.168.100.11:8040/";


    public  FragmentManager fragmentManager;
    private ActionBar actionBar;
    private RelativeLayout relativeLayout;
    private ActionBarDrawerToggle mToggle;
    private Toolbar toolbar;
    private DrawerLayout drawerLayout;
    private FragmentTransaction fragmentTransaction;
    public android.support.v4.app.ActionBarDrawerToggle mDrawer;
    private MenuItem menuItem;
    public String SUB_URL = "";
    public String sname = "";
    public int position = 0;
    public Fragment_2 fragment_2;
    FrameLayout actContent;
  /*  SharedPreferences pref;*/
    com.example.compaq.b2b_application.Adapters.ExpandableListAdapter listAdapter;
    ExpandableListView expListView;
    List<String> listDataHeader = new ArrayList<String>();
    HashMap<String, List<String>> listDataChild = new HashMap<String, List<String>>();
   /* private static final String PREF = "User_information";*/
     public  SharedPreferences sharedPref;
   public   SharedPreferences.Editor myEditor;
   public static TextView textCartItemCount;

   public int json_length=0;
   public String cart_item_no="";
    int mCartItemCount = 10;
 /*  public SharedPreferences cart_shared_preference;
    SharedPreferences.Editor cartEditor;*/
    ////login-variables
    // Alert Dialog Manager
    AlertDialogManager alert = new AlertDialogManager();

    // Session Manager Class
    SessionManagement session;

    // Button Logout
    Button btnLogout;
BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_main);
        super.onCreate(savedInstanceState);


       /* sharedPref = .getSharedPreferences(PREF, Context.MODE_PRIVATE);
        myEditor = sharedPref.edit();*/
        getApplicationContext().registerReceiver(receiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        sharedPref =getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        myEditor = sharedPref.edit();
       /* cart_shared_preference = getApplicationContext().getSharedPreferences("CART_ITEMS", 0);
        cartEditor=cart_shared_preference.edit();*/







        //>>>>>>>>>>>>>Login Part.............>>>>>>>>>>>>>>>>>>>>>>>>//////
        // Session class instance
        session = new SessionManagement(getApplicationContext());
        /*session.checkLogin();
*/
      /*  userInformation();*/

        /**
         * Call this function whenever you want to check user login
         * This will redirect user to LoginActivity is he is not
         * logged in
         * */


        // get user data from session


        // name
        /*String name = user.get(SessionManagement.KEY_NAME);
                TextView headerText=(TextView)findViewById(R.id.name);
                headerText.append(name);*/
        // email


        // displaying user data
       /* lblName.setText(Html.fromHtml("Name: <b>" + name + "</b>"));
        lblEmail.setText(Html.fromHtml("Email: <b>" + email + "</b>"));



        Logout button click event
     */


//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>end>>>>>>>>>>>>>>>>>>>>>>>>>>>>>///


            drawerLayout = (DrawerLayout) findViewById(R.id.drawer);

            mToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
            drawerLayout.addDrawerListener(mToggle);
            mToggle.syncState();

            toolbar = (Toolbar) findViewById(R.id.tool_bar);


            mToggle = new ActionBarDrawerToggle(this,
                    drawerLayout, toolbar, R.string.open, R.string.close);
            drawerLayout.addDrawerListener(mToggle);
            mToggle.syncState();
            setSupportActionBar(toolbar);

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().show();


            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.add(R.id.mainframe, new HomeFragment_1());

            fragmentTransaction.commit();
////////////////////////////////Bottom navigation/////////////////////
        bottomNavigationView=findViewById(R.id.bottom);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.home) {
                    fragmentManager = getSupportFragmentManager();
                    fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.mainframe, new HomeFragment_1());

                    fragmentTransaction.commit();

                    return true;
                }
                if (item.getItemId() == R.id.more) {
                    fragmentManager = getSupportFragmentManager();
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.mainframe, new Profile_fragment());

                fragmentTransaction.commit();
                return true;
            }
                return false;
            }
        });










            ///////////////////////Expandable_list View///////////////////////////////////



        expListView = (ExpandableListView) findViewById(R.id.navList);

            View listHeaderView = getLayoutInflater().inflate(R.layout.header, null, false);

            expListView.addHeaderView(listHeaderView);
            TextView header=(TextView)findViewById(R.id.header_name);




        sharedPref=getSharedPreferences("USER_DETAILS",0);
        String userfi=sharedPref.getString("firstname", null);
       Log.e("USERNAMEEE",userfi);
        header.setText(userfi);
            prepareListData();
            listAdapter = new com.example.compaq.b2b_application.Adapters.ExpandableListAdapter(MainActivity.this, listDataHeader, listDataChild);




            //expandAll();
            // Listview Group click listener
            expListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

                @Override
                public boolean onGroupClick(ExpandableListView parent, View v,
                                            int groupPosition, long id) {
                    //  mDrawerLayout.closeDrawers();
                    // Toast.makeText(getApplicationContext(),
                    // "Group Clicked " + listDataHeader.get(groupPosition),
                    // Toast.LENGTH_SHORT).show();

                    return false;
                }
            });

            // Listview Group expanded listener
            expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

                @Override
                public void onGroupExpand(int groupPosition) {
                    //  mDrawerLayout.closeDrawers();
                /*Toast.makeText(getApplicationContext(),
                        listDataHeader.get(groupPosition) + " Expanded",
                        Toast.LENGTH_SHORT).show();*/
                }
            });

            // Listview Group collasped listener
            expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

                @Override
                public void onGroupCollapse(int groupPosition) {


                }
            });

            // Listview on child click listener
            expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

                @Override
                public boolean onChildClick(ExpandableListView parent, View v,
                                            int groupPosition, int childPosition, long id) {
                    drawerLayout.closeDrawers();
                    expListView.collapseGroup(groupPosition);
                    String mi = listDataChild.get(
                            listDataHeader.get(groupPosition)).get(
                            childPosition);
                    Bundle bundle = new Bundle();

                    bundle.putString("Item_Clicked", mi);
                    // TODO Auto-generated method stub
                    Toast.makeText(
                            getApplicationContext(),
                            listDataHeader.get(groupPosition)
                                    + " : "
                                    + listDataChild.get(
                                    listDataHeader.get(groupPosition)).get(
                                    childPosition), Toast.LENGTH_LONG)
                            .show();

                    fragment_2 = new Fragment_2();
                    fragment_2.setArguments(bundle);
                    getSupportFragmentManager().beginTransaction().replace(R.id.mainframe, fragment_2).addToBackStack(null).commit();

                    return false;
                }
            });
        }


        // method to expand all groups
        private void expandAll () {
            int count = listAdapter.getGroupCount();
            for (int i = 0; i < count; i++) {
                expListView.expandGroup(i);
            }
        }


        /*
         * Preparing the list data
         */
       private RequestQueue requestQueue;
       private void prepareListData () {

            Log.d("Sidebar", "Entered");

            if(requestQueue==null)
            {
                 requestQueue = Volley.newRequestQueue(MainActivity.this);
            }
            URL_DATA = ip+"gate/b2b/catalog/api/v1/category/byFirstLevelCategory/b2b/jewellery?wholesaler=37";
            StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_DATA, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    try {
                        JSONArray ja_data = new JSONArray(response);
                        int length = ja_data.length();
                        for (int i = 0; i < length; i++) {
                            JSONObject jObj = ja_data.getJSONObject(i);

                            sname = (jObj.getString("name"));
                            listDataHeader.add(sname);
                            position = i;

                            SUB_URL =   ip+"gate/b2b/catalog/api/v1/category/byFirstLevelCategory/b2b/"+sname+"?wholesaler=37";
                            prepareSubListData(i, sname);


                            // Header, Child data

                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }){
                @Override
                public Map<String, String> getHeaders() {



                    String output=sharedPref.getString(ACCESS_TOKEN, null);
                    Log.d("ACESSSSSS>>>>>>>>TOKEN",output);
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Authorization","bearer "+output);
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }
            };

            requestQueue.add(stringRequest);
        }

        private void prepareSubListData ( final int i, final String sname1){
            StringRequest stringRequest = new StringRequest(Request.Method.GET, SUB_URL, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {

                    try {
                        JSONArray ja_data = new JSONArray(response);
                        Log.d("Length_of the Data", String.valueOf(ja_data.length()));
                        if (ja_data.length() == 0) {
                            final List<String> submenu = new ArrayList<String>();
                            submenu.add(sname1);

                            listDataChild.put(listDataHeader.get(i), submenu);


                        } else {
                            final List<String> submenu = new ArrayList<String>();
                            submenu.add(sname1);
                            for (int j = 0; j < ja_data.length(); j++) {
                                JSONObject jObj = ja_data.getJSONObject(j);

                                String subnames = jObj.getString("name");

                                submenu.add(subnames);
                            }
                            listDataChild.put(listDataHeader.get(i), submenu);


                        }

                        // Header, Child data
                        expListView.setAdapter(listAdapter);


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }){
                @Override
                public Map<String, String> getHeaders() {

                    sharedPref=getSharedPreferences("USER_DETAILS",0);

                    String output=sharedPref.getString(ACCESS_TOKEN, null);
                    Log.d("ACESSSSSS>>>>>>>>TOKEN",output);
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Authorization","bearer "+output);
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }
            };




            RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
            requestQueue.add(stringRequest);
        }
///////>>>>>>>>>>>>>Fetching user information<<<<<<<<<<<<<<<<<<<<<<<<<<<</////////
/*
public void userInformation ( ){

            String url="http://192.168.100.15:8769/uaa/b2b/api/v1/user/info";
    StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {


        @Override
        public void onResponse(String response) {
            try {
                JSONObject jObj = new JSONObject(response);

                String userid=jObj.getString("id");
                Log.e("USER    id",userid);

                myEditor.putString("userid",userid).apply();

                String userfirstname=jObj.getString("firstName");
                Log.e("USER    name",userfirstname);
                myEditor.putString("firstname",userfirstname);

                myEditor.commit();
                myEditor.apply();
                cartInformation(userid);

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

        }
    }){
        @Override
        public Map<String, String> getHeaders() {

            sharedPref=getSharedPreferences("USER_DETAILS",0);

            String output=sharedPref.getString(ACCESS_TOKEN, null);
            Log.d("ACESSSSSS>>>>>>>>TOKEN",output);
            Map<String, String> params = new HashMap<String, String>();
            params.put("Authorization","bearer "+output);
            params.put("Content-Type", "application/x-www-form-urlencoded");
            return params;
        }
    };




    RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
    requestQueue.add(stringRequest);
}



    public void cartInformation (String id ){

        String url=ip+"gate/b2b/order/api/v1/cart/customer/"+id;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jObj = new JSONObject(response);
                    JSONArray jsonArray=jObj.getJSONArray("items");
                    json_length= jsonArray.length();
                    Log.e("Length....", String.valueOf(json_length));


                    myEditor.putString("no_of_items", String.valueOf(json_length)).apply();
                    myEditor.commit();




                    String cartid=jObj.getString("id");
                    Log.e("Cart Id from Jason",cartid);
                    myEditor.putString("cartid",cartid).apply();
                    myEditor.commit();
                    myEditor.apply();

                    */
/*sharedPref=getSharedPreferences("User_information",0);*//*


                    String cart =sharedPref.getString("cartid","");
                    Log.e("Cart Id from SHARED",cart);
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                myEditor.putString("cartid","0").apply();
                myEditor.commit();
                myEditor.apply();


            }
        }){
            @Override
            public Map<String, String> getHeaders() {

                sharedPref=getSharedPreferences("USER_DETAILS",0);

                String output=sharedPref.getString(ACCESS_TOKEN, null);

                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type","application/json");
                params.put("Authorization","bearer "+output);
                return params;
            }
        };




        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(stringRequest);
    }

*/

        @Override
        public
        boolean onCreateOptionsMenu (Menu menu){
          /*  MenuInflater menuInflater = getMenuInflater();
            menuInflater.inflate(R.menu.actionbar_icons, menu);
*/

            getMenuInflater().inflate(R.menu.actionbar_icons, menu);

            final MenuItem menuItem = menu.findItem(R.id.cart);

            View actionView = MenuItemCompat.getActionView(menuItem);
            textCartItemCount = (TextView) actionView.findViewById(R.id.cart_badge);
            setupBadge(getApplicationContext());
          /*  cart_shared_preference = getApplicationContext().getSharedPreferences("CART_ITEMS", 0);*/
            sharedPref =getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            cart_item_no=sharedPref.getString("no_of_items","");
             textCartItemCount.setText(cart_item_no);
           /* setupBadge();*/

            actionView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onOptionsItemSelected(menuItem);
                }
            });

            return true;
        }



    public  void setupBadge(Context context) {

      /*  cart_shared_preference = context.getSharedPreferences("CART_ITEMS", 0);*/
        sharedPref =context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        cart_item_no=sharedPref.getString("no_of_items","");
        textCartItemCount.setText(cart_item_no);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mToggle.onOptionsItemSelected(item)) {
            return true;
        }
        if (item.getItemId() == R.id.search) {
            Intent i = new Intent(this, Search_Activity.class);
            startActivity(i);
            return true;
        }
        if (item.getItemId() == R.id.cart) {
            Intent i = new Intent(this, Cart_Activity.class);
            startActivity(i);
            return true;

        }
        return super.onOptionsItemSelected(item);
    }

    /*private void setupBadge() {

        if (textCartItemCount != null) {
            if (mCartItemCount == 0) {
                if (textCartItemCount.getVisibility() != View.GONE) {
                    textCartItemCount.setVisibility(View.GONE);
                }
            } else {
                textCartItemCount.setText(String.valueOf(Math.min(mCartItemCount, 99)));
                if (textCartItemCount.getVisibility() != View.VISIBLE) {
                    textCartItemCount.setVisibility(View.VISIBLE);
                }
            }
        }
    }*/
/*

        public
        boolean onOptionsItemSelected (MenuItem item){

            if (mToggle.onOptionsItemSelected(item)) {
                return true;
            }
            if (item.getItemId() == R.id.search) {
                Intent i = new Intent(this, Search_Activity.class);
                startActivity(i);
                return true;
            }
            if (item.getItemId() == R.id.cart) {
                Intent i = new Intent(this, Cart_Activity.class);
                startActivity(i);
                return true;

            }

            return super.onOptionsItemSelected(item);
        }
*/

        public
        void setDrawerLocked ( boolean enabled){
            if (enabled) {
                drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
            } else {
                drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
            }


        }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(!ConnectivityStatus .isConnected(getApplicationContext())){
                alert.showAlertDialog(MainActivity.this, "No Internet!", "Please Check your internet Connection", "internet");
            }else {
                // connected

            }
        }
    };
    @Override
    protected void onResume() {
        super.onResume();
        getApplicationContext().registerReceiver(receiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));

    }

    @Override
    protected void onPause() {
        super.onPause();
        getApplicationContext().registerReceiver(receiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));


    }

    }

