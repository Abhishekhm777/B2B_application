package com.example.compaq.b2b_application.Fragments;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.compaq.b2b_application.R;

import static com.example.compaq.b2b_application.SessionManagement.PREF_NAME;

/**
 * A simple {@link Fragment} subclass.
 */
public class OTP_fragment extends Fragment {
    EditText editText;
    Button submit,resend;
    SharedPreferences sharedPref;
    SharedPreferences.Editor myEditior;

    public OTP_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_otp_fragment, container, false);

        sharedPref =getActivity().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        myEditior = sharedPref.edit();

        String url = sharedPref.getString("RESEND_OTP",null) ;
        Log.e("OOOOOOTTTTTPPP",url);
        editText=(EditText)view.findViewById(R.id.otp_edittext);
        submit=(Button)view.findViewById(R.id.submit_otp);
        resend=(Button)view.findViewById(R.id.resend_otp);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String otpurl = "https://server.mrkzevar.com/uaa/api/v1/user/checkOTP/" + editText.getText().toString() +"?email=" + sharedPref.getString("PASSWORD_ID", null);
                Log.d("res...", otpurl);
                RequestQueue rqueue= Volley.newRequestQueue(getActivity());
                StringRequest stringRequest=new StringRequest(Request.Method.GET, otpurl, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.equals("true")){
                            Log.d("otp sucess..",response);
                            FragmentManager fragmentManager =getActivity().getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            fragmentTransaction.replace(R.id.forgpass_layout, new Password_reset());
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();
                        }
                        else{
                            editText.setError("Incorrect OTP");

                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
                rqueue.add(stringRequest);


            }
        });

        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.setText("");

                String url = sharedPref.getString("RESEND_OTP",null) ;
                RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Log.d("res2...", response.toString());


                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });

                requestQueue.add(stringRequest);


            }
        });

        return view;
    }

}
