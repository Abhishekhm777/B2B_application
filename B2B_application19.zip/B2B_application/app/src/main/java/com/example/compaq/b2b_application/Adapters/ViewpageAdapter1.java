package com.example.compaq.b2b_application.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.compaq.b2b_application.Fragments.HomeFragment_1;
import com.example.compaq.b2b_application.R;

public
class ViewpageAdapter1 extends PagerAdapter{

    public HomeFragment_1 context;
    public LayoutInflater layoutInflater;
    public Integer[] arr={R.drawable.home_page_image1,R.drawable.home_page_image2,R.drawable.home_page_image3};




    public ViewpageAdapter1(HomeFragment_1 context)
    {
        this.context=context;
    }
    @Override
    public int getCount() {
        return arr.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return (view==(LinearLayout)object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        /* layoutInflater=(LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);*/
        layoutInflater=(LayoutInflater)context.getLayoutInflater();
        layoutInflater.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View item_view=layoutInflater.inflate(R.layout.viewpager1_custome_layout,container,false);
        ImageView imageView=(ImageView)item_view.findViewById(R.id.imageview);
        imageView.setImageResource(Integer.parseInt(String.valueOf(arr[position])));


        container.addView(item_view);
        return item_view;

        /*ViewPager viewPager=(ViewPager) container;
        viewPager.addView(item_view,0);
        return item_view;*/
    }

    public void destroyItem(ViewGroup container,int position,Object object){
        container.removeView((LinearLayout)object);


       /* ViewPager vp=(ViewPager)container;
        View view=(View)object;
        vp.removeView(view);*/
    }
}
