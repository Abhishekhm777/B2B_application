package com.example.compaq.b2b_application.Model;

public class Check_out_Recyclemodel {
    private String  name;
    private String img_url;
    private String weight;
    private String id;
    private String seal;
    private int del_id;


    public Check_out_Recyclemodel(String name, String img_url, String weight, String id, String seal,int del_id) {
        this.name=name;
        this.img_url=img_url;
        this.weight=weight;
        this.id=id;
        this.seal=seal;
        this.del_id=del_id;
    }


    public String getSeal() {
        return seal;
    }

    public void setSeal(String seal) {
        this.seal = seal;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImg_url() {
        return img_url;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public int getDel_id() {
        return del_id;
    }

    public void setDel_id(int del_id) {
        this.del_id = del_id;
    }
}


